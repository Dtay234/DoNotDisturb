﻿
using var game = new Do_Not_Disturb.Game1();
game.Run();
